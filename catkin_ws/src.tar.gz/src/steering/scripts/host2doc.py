#!/usr/bin/env python
import rospy
import time
# ROS Image message
from std_msgs.msg import String
import numpy as np
# INPUT_TOPIC = "/apollo/sensor/camera/traffic/image_long"
INPUT_TOPIC = "/local_steer_net"
OUTPUT_TOPIC = "/docker_steer_net"
timestamps = []

def callback(img, pub):
    global timestamps
    timestamps.append(rospy.Time.now().nsecs - float(img.data))
    print(rospy.get_rostime().secs)
    print(rospy.get_time())
    print(rospy.Time.now().secs)
    print(float(img.data))
    print()
    print(rospy.get_rostime().secs - float(img.data))
    v = np.array(timestamps)
    # print(v.mean(), v.std())
    pub.publish(img)

def main():
    rospy.init_node('host2doc')
    pub = rospy.Publisher(OUTPUT_TOPIC, String, queue_size= 10)
    rospy.Subscriber(INPUT_TOPIC, String, callback, pub, queue_size=10)
    rospy.spin()

if __name__ == '__main__':
    main()
